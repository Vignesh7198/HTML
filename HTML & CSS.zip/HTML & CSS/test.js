result = 6%5==0?"true":"false"

console.log(result);

let day="ggg";

switch(day){

    case 'Monday':
console.log(day);
}

num = 9
num2 = 4

console.log(`the addition
              of ${num} and is ${num2}`)


              let i = 1;

// while(i<=5){
//     console.log("OK");
// }

for(j=0;j<2;j++){
console.log("test")
}